#!/bin/bash

# output version
bash .ci/printinfo.sh

make clean > /dev/null

echo "checking..."
./helper.pl --check-all || exit 1

exit 0

# ref:         HEAD -> develop
# git commit:  4ed50d8da1b8dabe02c5ffa2abca3c57811bdf14
# commit time: 2019-06-05 09:24:19 +0200
