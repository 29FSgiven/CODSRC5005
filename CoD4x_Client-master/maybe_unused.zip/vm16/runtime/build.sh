#!/bin/bash

FLAGS="-g -Wall -O0"

gcc -c $FLAGS "embedvm.c"
gcc -c $FLAGS "evmdemo.c"

echo Linking...
gcc $FLAGS -o vm *.o -static-libgcc -Wl,-Map=vm.map

