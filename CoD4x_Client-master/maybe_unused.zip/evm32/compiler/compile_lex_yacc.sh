#!/bin/bash

yacc -d -r all parser.y
flex lexer.l
