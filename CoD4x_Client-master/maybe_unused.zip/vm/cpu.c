#include <stdint.h>

#include "cpu.h"
#include "opcode_table.h"

#define MAX_REGISTERS 32

typedef unsigned int VirtualAddress;
typedef signed int VirtualOffset;
typedef uint8_t OPC;

union GeneralPurposeRegister_t
{
    uint8_t byte;
    uint16_t word;
    uint32_t dword;
    float fsingle;
    uint32_t data;
};

struct Register_t
{
    uint32_t v;
};

struct Segment_t
{
    byte* offsetRAW;
    unsigned int offsetVirtual;
    unsigned int size;
    unsigned int flags;
};

struct Flags_t
{
    bool c; //Carryflag
    bool z; //Zeroflag
    bool s; //Signflag
    bool o; //overflow
};

struct Callstack_t
{
    VirtualAddress ret;
    VirtualAddress framept;
};

struct vm_t
{
    byte* ram_start;
    unsigned int ramsize;
    
    struct Callstack_t callstack;
    unsigned int callstacksize;

    unsigned int entrypoint;
    struct Segment_t* segments;
    unsigned int segmentcount;
    //Finally the CPU state here
    union GeneralPurposeRegister_t R[MAX_REGISTERS];

    //Callstack grows from buttom to top
    struct Register_t SP; //Stackpointer for callstack
    struct Register_t FP; //Framepointer addressing LocalVariableStack (LSP) but stored onto Callstack

    //Local variable stack grows from top to bottom
    struct Register_t LSP; //Local variable Stack

    struct Register_t IP; //Instruction Pointer

    struct Flags_t flags;


};


struct vm_t Create_VM(int ramsize, byte* image, imagesize)
{
    int segmentcount = 0;
    int callstacksize = 0x1000;
    struct vm_t *vm;
    //Have to add PE loader here later

    int memsize = ramcount + sizeof(struct vm_t) + segmentcount * sizeof(struct segment_t) + callstacksize * sizeof(Callstack_t);

    vm = malloc(memsize);

    memset(vm, 0, memsize);
    
    vm->segments = (byte*)vm + sizeof(struct vm_t);
    vm->segmentcount = segmentcount;
    vm->callstack = (byte*)vm + sizeof(struct vm_t) + segmentcount * sizeof(struct segment_t);
    vm->callstacksize = callstacksize;
    vm->ramsize = ramsize;
    vm->ram_start = (byte*)vm + sizeof(struct vm_t) + segmentcount * sizeof(struct segment_t) + callstacksize * sizeof(Callstack_t);
    vm->SP = ramsize;
    vm->FP = vm->SP;
}

void Invalid_OpcodeException(OPC opcode, VirtualAddress addr)
{

}

void Invalid_MemoryAccessException(Register_t ip, VirtualAddress addr)
{

}

OPC Read_OpcodeHigh6()
{
    return 0;
}

OPC Read_OpcodeLow4()
{
    return 0;
}

void PushCallstack(struct vm_t* vm, VirtualAddress ret, VirtualAddress framept)
{
    if(vm->SP.v >= vm->callstacksize)
    {
        Invalid_MemoryAccessException(vm->IP, vm->SP.v);
    }
    vm->callstack[vm->SP.v].ret = ret;
    vm->callstack[vm->SP.v].framept = framept;
    ++vm->SP.v;
}

void PopCallstack(struct vm_t* vm, VirtualAddress* ret, VirtualAddress* framept)
{
    if(vm->SP.v <= 0)
    {
        Invalid_MemoryAccessException(vm->IP, vm->SP.v);
    }
    --vm->SP.v;
    *ret = vm->callstack[vm->SP.v].ret;
    *framept = vm->callstack[vm->SP.v].framept;
}

void PushStack(struct vm_t* vm, union GeneralPurposeRegister_t reg)
{
    if(vm->LSP.v <= 0)
    {
        Invalid_MemoryAccessException(vm->IP, vm->LSP.v - sizeof(reg));
    }
    vm->LSP.v -= sizeof(reg);
    uint8_t* stackdata = (uint8_t*)vm->ram_start + vm->LSP.v;
    (*(GeneralPurposeRegister_t*)stackdata)->data = reg.data;
}

GeneralPurposeRegister_t PopStack(struct vm_t* vm)
{
    GeneralPurposeRegister_t reg;
    uint8_t* stackdata = (uint8_t*)vm->ram_start + vm->LSP.v;
    reg.data = (*(GeneralPurposeRegister_t*)stackdata)->data;
    if(vm->LSP.v >= vm->ramsize)
    {
        Invalid_MemoryAccessException(vm->IP, vm->LSP.v + sizeof(reg));
    }
    vm->LSP.v += sizeof(reg);

}

void WriteDWORDRam(struct vm_t* vm, VirtualAddress addr, uint32_t dword)
{
    if(addr > (vm->ramsize - sizeof(dword)))
    {
        Invalid_MemoryAccessException(vm->IP, addr);
    }
    *(uint32_t*)(vm->ram_start + addr) = dword;
}

uint32_t ReadDWORDRam(struct vm_t* vm, VirtualAddress addr)
{
    uint32_t dword;
    if(addr > (vm->ramsize - sizeof(dword)))
    {
        Invalid_MemoryAccessException(vm->IP, addr);
    }
    dword = *(uint32_t*)(vm->ram_start + addr);
    return dword;
}   


void WriteWORDRam(struct vm_t* vm, VirtualAddress addr, uint16_t word)
{
    if(addr > (vm->ramsize - sizeof(word)))
    {
        Invalid_MemoryAccessException(vm->IP, addr);
    }
    *(uint16_t*)(vm->ram_start + addr) = word;
}

uint16_t ReadWORDRam(struct vm_t* vm, VirtualAddress addr)
{
    uint16_t word;
    if(addr > (vm->ramsize - sizeof(word)))
    {
        Invalid_MemoryAccessException(vm->IP, addr);
    }
    word = *(uint16_t*)(vm->ram_start + addr);
    return word;
}   

void WriteBYTERam(struct vm_t* vm, VirtualAddress addr, uint8_t byte)
{
    if(addr > (vm->ramsize - sizeof(byte)))
    {
        Invalid_MemoryAccessException(vm->IP, addr);
    }
    *(uint8_t*)(vm->ram_start + addr) = byte;
}

uint8_t ReadBYTERam(struct vm_t* vm, VirtualAddress addr)
{
    uint8_t byte;
    if(addr > (vm->ramsize - sizeof(byte)))
    {
        Invalid_MemoryAccessException(vm->IP, addr);
    }
    byte = *(uint8_t*)(vm->ram_start + addr);
    return byte;
}   

void SetSignZeroFlags(struct vm_t* vm, uint32_t v)
{
    if(v == 0)
    {
        vm->flags.z = true;
    }else{
        vm->flags.z = false;
    }
    if((signed int)v < 0)
    {
        vm->flags.s = true;
    }else{
        vm->flags.s = false;
    }
}

void VM_Execute(struct vm_t* vm)
{
    VirtualAddress returnAddress;
    VirtualAddress absAddress;
    VirtualOffset branchdest;
    VirtualAddress varloc;
    VirtualAddress framept;
    uint32_t variableSpace;

    uint8_t registerindex;
    uint8_t sourcereg, destinationreg, operatorreg;
    union GeneralPurposeRegister_t gpr;
    uint32_t imm, aresult;
    int32_t sresult;
    int64_t lresult;

    OPC opcode = Read_CodeBYTE(vm, 0);

    switch(opcode)
    {
        case ENTER:
            //Store return address
            returnAddress = vm->IP.v + sizeof(Register_t) + sizeof(OPC);
            PushCallstack(vm, returnAddress, vm->LSP.r);
            //Now finally jump to the address of function
            branchdest = Read_CodeDWORD(vm, 1);
            vm->IP.v += ;
            vm->IP.v += branchdest;
            break;
        case ENTER_REG:
            //Store return address
            returnAddress = vm->IP.v + sizeof(char) + sizeof(OPC);
            PushCallstack(vm, returnAddress, vm->LSP.r);
            //Now finally jump to the address of function
            registerindex = Read_CodeBYTE(vm, 1);
            vm->IP.v = vm->R[registerindex % MAX_REGISTERS].dword;
            break;
        case LEAVE:
            PopCallstack(vm, &returnAddress, &framept);
            vm->LSP.v = framept;
            vm->IP.v = returnAddress;
            break;
        case BRANCH:
            branchdest = Read_CodeDWORD(vm, 1);
            vm->IP.v += 5;
            vm->IP.v += branchdest;
            break;
        case BRANCH_REG:
            registerindex = Read_CodeBYTE(vm, 1);
            vm->IP.v = vm->R[registerindex % MAX_REGISTERS].dword;
            break;
        case BRANCH_CARRY
            branchdest = Read_CodeDWORD(vm, 1);
            vm->IP.v += 5;
            if(vm->flags.c)
            {
                vm->IP.v += branchdest;
            }
            break;
        case BRANCH_NOCARRY:
            branchdest = Read_CodeDWORD(vm, 1);
            vm->IP.v += 5;
            if(!vm->flags.c)
            {
                vm->IP.v += branchdest;
            }
            break;
        case BRANCH_ZERO
            branchdest = Read_CodeDWORD(vm, 1);
            vm->IP.v += 5;
            if(vm->flags.z)
            {
                vm->IP.v += branchdest;
            }
            break;
        case BRANCH_NOZERO
            branchdest = Read_CodeDWORD(vm, 1);
            vm->IP.v += 5;
            if(!vm->flags.z)
            {
                vm->IP.v += branchdest;
            }
            break;
        case BRANCH_SIGN
            branchdest = Read_CodeDWORD(vm, 1);
            vm->IP.v += 5;
            if(vm->flags.s)
            {
                vm->IP.v += branchdest;
            }
            break;
        case BRANCH_NOSIGN
            branchdest = Read_CodeDWORD(vm, 1);
            vm->IP.v += 5;
            if(!vm->flags.s)
            {
                vm->IP.v += branchdest;
            }
            break;
        case PUSH:
            registerindex = Read_CodeBYTE(vm, 1);
            gpr.data = vm->R[registerindex % MAX_REGISTERS].data;
            PushStack(vm, gpr);
            vm->IP.v += 2;
            break;
        case POP:
            registerindex = Read_CodeBYTE(vm, 1);
            gpr = PopStack(vm);
            vm->R[registerindex % MAX_REGISTERS].data = gpr.data;
            vm->IP.v += 2;
            break;
        case LOCALALLOC:
            variableSpace = Read_CodeDWORD(vm, 1);
            vm->LSP.v -= variableSpace;
            vm->IP.v += 5;
            break;
        case LGETPTR: //Get pointer for local variable stack
            registerindex = Read_CodeBYTE(vm, 1);
            varloc = Read_CodeDWORD(vm, 2);
            absAddress = vm->LSP.v + varloc;
            if(absAddress >= vm->ramsize)
            {
                Invalid_MemoryAccessException(vm->IP, absAddress);
            }
            vm->R[registerindex % MAX_REGISTERS].dword = absAddress;
            vm->IP.v += 6;
            break;
        case MOV_DWORDPTR:  //mov_dwordptr [r0], r1
            sourcereg = Read_CodeBYTE(vm, 1); //r1
            destinationreg = Read_CodeBYTE(vm, 2); //r0
            WriteDWORDRam(vm, vm->R[destinationreg % MAX_REGISTERS].dword, vm->R[sourcereg % MAX_REGISTERS].dword);
            vm->IP.v += 3;
            break;
        case MOVR_DWORDPTR: //mov_rdwordptr r0, [r1]
            sourcereg = Read_CodeBYTE(vm, 1); //r1
            destinationreg = Read_CodeBYTE(vm, 2); //r0
            vm->R[destinationreg % MAX_REGISTERS].dword = ReadDWORDRam(vm, vm->R[sourcereg % MAX_REGISTERS].dword);
            vm->IP.v += 3;
            break;
        case MOV_WORDPTR:  //mov_wordptr [r0], r1
            sourcereg = Read_CodeBYTE(vm, 1); //r1
            destinationreg = Read_CodeBYTE(vm, 2); //r0
            WriteWORDRam(vm, vm->R[destinationreg % MAX_REGISTERS].dword, vm->R[sourcereg % MAX_REGISTERS].word);
            vm->IP.v += 3;
            break;
        case MOVR_WORDPTR: //mov_rwordptr r0, [r1]
            sourcereg = Read_CodeBYTE(vm, 1); //r1
            destinationreg = Read_CodeBYTE(vm, 2); //r0
            vm->R[destinationreg % MAX_REGISTERS].word = ReadWORDRam(vm, vm->R[sourcereg % MAX_REGISTERS].dword);
            vm->IP.v += 3;
            break;
        case MOV_BYTEPTR:  //mov_byteptr [r0], r1
            sourcereg = Read_CodeBYTE(vm, 1); //r1
            destinationreg = Read_CodeBYTE(vm, 2); //r0
            WriteWORDRam(vm, vm->R[destinationreg % MAX_REGISTERS].dword, vm->R[sourcereg % MAX_REGISTERS].byte);
            vm->IP.v += 3;
            break;
        case MOVR_BYTEPTR: //mov_rbyteptr r0, [r1]
            sourcereg = Read_CodeBYTE(vm, 1); //r1
            destinationreg = Read_CodeBYTE(vm, 2); //r0
            vm->R[destinationreg % MAX_REGISTERS].byte = ReadWORDRam(vm, vm->R[sourcereg % MAX_REGISTERS].dword);
            vm->IP.v += 3;
            break;
        case MOV_DWORD:
            sourcereg = Read_CodeBYTE(vm, 1); //r1
            destinationreg = Read_CodeBYTE(vm, 2); //r0
            vm->R[destinationreg % MAX_REGISTERS].dword = vm->R[sourcereg % MAX_REGISTERS].dword;
            vm->IP.v += 3;
            break;
        case MOV_WORD:
            sourcereg = Read_CodeBYTE(vm, 1); //r1
            destinationreg = Read_CodeBYTE(vm, 2); //r0
            vm->R[destinationreg % MAX_REGISTERS].word = vm->R[sourcereg % MAX_REGISTERS].word;
            vm->IP.v += 3;
            break;        
        case MOV_BYTE:
            sourcereg = Read_CodeBYTE(vm, 1); //r1
            destinationreg = Read_CodeBYTE(vm, 2); //r0
            vm->R[destinationreg % MAX_REGISTERS].byte = vm->R[sourcereg % MAX_REGISTERS].byte;
            vm->IP.v += 3;
            break;  
        case MOV_WORDSIGNEXT:
            sourcereg = Read_CodeBYTE(vm, 1); //r1
            destinationreg = Read_CodeBYTE(vm, 2); //r0
            vm->R[destinationreg % MAX_REGISTERS].dword = (int16_t)vm->R[sourcereg % MAX_REGISTERS].word;
            vm->IP.v += 3;
            break;
        case MOV_BYTESIGNEXT:
            sourcereg = Read_CodeBYTE(vm, 1); //r1
            destinationreg = Read_CodeBYTE(vm, 2); //r0
            vm->R[destinationreg % MAX_REGISTERS].dword = (int8_t)vm->R[sourcereg % MAX_REGISTERS].byte;
            vm->IP.v += 3;
            break;
        case MOV_WORDZEROEXT:
            sourcereg = Read_CodeBYTE(vm, 1); //r1
            destinationreg = Read_CodeBYTE(vm, 2); //r0
            vm->R[destinationreg % MAX_REGISTERS].dword = (uint16_t)vm->R[sourcereg % MAX_REGISTERS].word;
            vm->IP.v += 3;
            break;
        case MOV_BYTEZEROEXT:
            sourcereg = Read_CodeBYTE(vm, 1); //r1
            destinationreg = Read_CodeBYTE(vm, 2); //r0
            vm->R[destinationreg % MAX_REGISTERS].dword = (uint8_t)vm->R[sourcereg % MAX_REGISTERS].byte;
            vm->IP.v += 3;
            break;
        case CMP_DWORD:
            sourcereg = Read_CodeBYTE(vm, 1); //r1
            operatorreg = Read_CodeBYTE(vm, 2); //r0

            sresult = vm->R[sourcereg % MAX_REGISTERS].dword - vm->R[operatorreg % MAX_REGISTERS].dword;
            if(vm->R[sourcereg % MAX_REGISTERS].dword < vm->R[operatorreg % MAX_REGISTERS].dword)
            {
                vm->flags.c = true;
            }else{
                vm->flags.c = false;
            }
            if(((signed int)vm->R[operatorreg % MAX_REGISTERS].dword > 0 && (signed int)vm->R[sourcereg % MAX_REGISTERS].dword < 0 && (signed int)sresult < 0)
               ((signed int)vm->R[operatorreg % MAX_REGISTERS].dword < 0 && (signed int)vm->R[sourcereg % MAX_REGISTERS].dword > 0 && (signed int)sresult > 0))
            {
                vm->flags.o = true;
            }else{
                vm->flags.o = false;
            }
            SetSignZeroFlags(vm, sresult);

            vm->IP.v += 3;
            break;
        case CMP_WORD:
            sourcereg = Read_CodeBYTE(vm, 1); //r1
            operatorreg = Read_CodeBYTE(vm, 2); //r0

            sresult = vm->R[sourcereg % MAX_REGISTERS].word - vm->R[operatorreg % MAX_REGISTERS].word;
            if(vm->R[sourcereg % MAX_REGISTERS].word < vm->R[operatorreg % MAX_REGISTERS].word)
            {
                vm->flags.c = true;
            }else{
                vm->flags.c = false;
            }
            if(((signed int)vm->R[operatorreg % MAX_REGISTERS].word > 0 && (signed int)vm->R[sourcereg % MAX_REGISTERS].word < 0 && (signed int)sresult < 0)
               ((signed int)vm->R[operatorreg % MAX_REGISTERS].word < 0 && (signed int)vm->R[sourcereg % MAX_REGISTERS].word > 0 && (signed int)sresult > 0))
            {
                vm->flags.o = true;
            }else{
                vm->flags.o = false;
            }
            SetSignZeroFlags(vm, sresult);

            vm->IP.v += 3;
            break;
        case CMP_BYTE:
            sourcereg = Read_CodeBYTE(vm, 1); //r1
            operatorreg = Read_CodeBYTE(vm, 2); //r0

            sresult = vm->R[sourcereg % MAX_REGISTERS].byte - vm->R[operatorreg % MAX_REGISTERS].byte;
            if(vm->R[sourcereg % MAX_REGISTERS].byte < vm->R[operatorreg % MAX_REGISTERS].byte)
            {
                vm->flags.c = true;
            }else{
                vm->flags.c = false;
            }
            if(((signed int)vm->R[operatorreg % MAX_REGISTERS].byte > 0 && (signed int)vm->R[sourcereg % MAX_REGISTERS].byte < 0 && (signed int)sresult < 0)
               ((signed int)vm->R[operatorreg % MAX_REGISTERS].byte < 0 && (signed int)vm->R[sourcereg % MAX_REGISTERS].byte > 0 && (signed int)sresult > 0))
            {
                vm->flags.o = true;
            }else{
                vm->flags.o = false;
            }
            SetSignZeroFlags(vm, sresult);

            vm->IP.v += 3;
            break;
        case CMP_IMM:
            sourcereg = Read_CodeBYTE(vm, 1); //r1
            imm = Read_CodeDWORD(vm, 2); //r0

            aresult = vm->R[sourcereg % MAX_REGISTERS].dword - imm;
            if(vm->R[sourcereg % MAX_REGISTERS].dword < imm)
            {
                vm->flags.c = true;
            }else{
                vm->flags.c = false;
            }
            if(((signed int)imm > 0 && (signed int)vm->R[sourcereg % MAX_REGISTERS].dword < 0 && (signed int)aresult < 0)
               ((signed int)imm < 0 && (signed int)vm->R[sourcereg % MAX_REGISTERS].dword > 0 && (signed int)aresult > 0))
            {
                vm->flags.o = true;
            }else{
                vm->flags.o = false;
            }            
            SetSignZeroFlags(vm, aresult);

            vm->IP.v += 6;
            break;
        case LSHIFT:
            sourcereg = Read_CodeBYTE(vm, 1); //r1
            destinationreg = Read_CodeBYTE(vm, 2); //r0
            operatorreg = Read_CodeBYTE(vm, 3); //r0
            aresult = vm->R[sourcereg % MAX_REGISTERS].dword << vm->R[operatorreg % MAX_REGISTERS].byte;

            SetSignZeroFlags(vm, aresult);

            vm->flags.c = vm->R[sourcereg % MAX_REGISTERS].dword & (1 << (32 - vm->R[operatorreg % MAX_REGISTERS].byte));
            vm->R[destinationreg % MAX_REGISTERS].dword = aresult;
            vm->IP.v += 4;
            break;
        case RSHIFT:
            sourcereg = Read_CodeBYTE(vm, 1); //r1
            destinationreg = Read_CodeBYTE(vm, 2); //r0
            operatorreg = Read_CodeBYTE(vm, 3); //r0
            aresult = vm->R[sourcereg % MAX_REGISTERS].dword >> vm->R[operatorreg % MAX_REGISTERS].byte;

            SetSignZeroFlags(vm, aresult);

            vm->flags.c = vm->R[sourcereg % MAX_REGISTERS].dword & (1 << (-1 + vm->R[operatorreg % MAX_REGISTERS].byte));
            vm->R[destinationreg % MAX_REGISTERS].dword = aresult;
            vm->IP.v += 4;
            break;
        case XOR:
            sourcereg = Read_CodeBYTE(vm, 1); //r1
            destinationreg = Read_CodeBYTE(vm, 2); //r0
            operatorreg = Read_CodeBYTE(vm, 3); //r0
            aresult = vm->R[sourcereg % MAX_REGISTERS].dword ^ vm->R[operatorreg % MAX_REGISTERS].dword;
            SetSignZeroFlags(vm, aresult);
            vm->R[destinationreg % MAX_REGISTERS].dword = aresult;
            vm->IP.v += 4;
            break;
        case OR:
            sourcereg = Read_CodeBYTE(vm, 1); //r1
            destinationreg = Read_CodeBYTE(vm, 2); //r0
            operatorreg = Read_CodeBYTE(vm, 3); //r0
            aresult = vm->R[sourcereg % MAX_REGISTERS].dword | vm->R[operatorreg % MAX_REGISTERS].dword;

            SetSignZeroFlags(vm, aresult);

            vm->R[destinationreg % MAX_REGISTERS].dword = aresult;
            vm->IP.v += 4;
            break;
        case AND:
            sourcereg = Read_CodeBYTE(vm, 1); //r1
            destinationreg = Read_CodeBYTE(vm, 2); //r0
            operatorreg = Read_CodeBYTE(vm, 3); //r0
            aresult = vm->R[sourcereg % MAX_REGISTERS].dword & vm->R[operatorreg % MAX_REGISTERS].dword;

            SetSignZeroFlags(vm, aresult);

            vm->R[destinationreg % MAX_REGISTERS].dword = aresult;
            vm->IP.v += 4;
            break;
        case NOT:
            sourcereg = Read_CodeBYTE(vm, 1); //r1
            destinationreg = Read_CodeBYTE(vm, 2); //r0
            operatorreg = Read_CodeBYTE(vm, 3); //r0
            aresult = vm->R[sourcereg % MAX_REGISTERS].dword ~ vm->R[operatorreg % MAX_REGISTERS].dword;

            SetSignZeroFlags(vm, aresult);
            vm->R[destinationreg % MAX_REGISTERS].dword = aresult;
            vm->IP.v += 4;
            break;
        case ADD:
            sourcereg = Read_CodeBYTE(vm, 1); //r1
            destinationreg = Read_CodeBYTE(vm, 2); //r0
            operatorreg = Read_CodeBYTE(vm, 3); //r0
            aresult = vm->R[sourcereg % MAX_REGISTERS].dword + vm->R[operatorreg % MAX_REGISTERS].dword;
            if(aresult < vm->R[sourcereg % MAX_REGISTERS].dword)
            {
                vm->flags.c = true;
            }else{
                vm->flags.c = false;
            }
            if(((signed int)vm->R[operatorreg % MAX_REGISTERS].dword > 0 && (signed int)vm->R[sourcereg % MAX_REGISTERS].dword > 0 && (signed int)aresult <= 0)
                ((signed int)vm->R[operatorreg % MAX_REGISTERS].dword < 0 && (signed int)vm->R[sourcereg % MAX_REGISTERS].dword < 0 && (signed int)aresult >= 0))
            {
                vm->flags.o = true;
            }else{
                vm->flags.o = false;
            }
            SetSignZeroFlags(vm, aresult);
            vm->R[destinationreg % MAX_REGISTERS].dword = aresult;
            vm->IP.v += 4;
            break;
        case SUB:
            sourcereg = Read_CodeBYTE(vm, 1); //r1
            destinationreg = Read_CodeBYTE(vm, 2); //r0
            operatorreg = Read_CodeBYTE(vm, 3); //r0
            aresult = vm->R[sourcereg % MAX_REGISTERS].dword - vm->R[operatorreg % MAX_REGISTERS].dword;
            if(vm->R[sourcereg % MAX_REGISTERS].dword < vm->R[operatorreg % MAX_REGISTERS].dword)
            {
                vm->flags.c = true;
            }else{
                vm->flags.c = false;
            }
            if(((signed int)vm->R[operatorreg % MAX_REGISTERS].dword > 0 && (signed int)vm->R[sourcereg % MAX_REGISTERS].dword < 0 && (signed int)aresult < 0)
               ((signed int)vm->R[operatorreg % MAX_REGISTERS].dword < 0 && (signed int)vm->R[sourcereg % MAX_REGISTERS].dword > 0 && (signed int)aresult > 0))
            {
                vm->flags.o = true;
            }else{
                vm->flags.o = false;
            }            
            SetSignZeroFlags(vm, aresult);
            vm->R[destinationreg % MAX_REGISTERS].dword = aresult;
            vm->IP.v += 4;
            break;          
        case IMUL:
            sourcereg = Read_CodeBYTE(vm, 1); //r1
            destinationreg = Read_CodeBYTE(vm, 2); //r0
            operatorreg = Read_CodeBYTE(vm, 3); //r0
            lresult = (int64_t)vm->R[sourcereg % MAX_REGISTERS].dword * (int64_t)vm->R[operatorreg % MAX_REGISTERS].dword;
            if(lresult > 0x7fffffff || lresult < 0x80000000)
            {
                vm->flags.o = true;
            }else{
                vm->flags.o = false;
            }
            
            vm->IP.v += 4;            
            break;
        case IDIV:
            sourcereg = Read_CodeBYTE(vm, 1); //r1
            destinationreg = Read_CodeBYTE(vm, 2); //r0
            operatorreg = Read_CodeBYTE(vm, 3); //r0

            vm->IP.v += 4;         
            break;
        default:
            Invalid_OpcodeException(opcode, vm->IP);
    }

}

