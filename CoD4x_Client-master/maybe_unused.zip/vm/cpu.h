#ifndef __CPU_H__
#define __CPU_H__

typedef unsigned int OPC; 






#endif