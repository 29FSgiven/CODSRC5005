struct A {} int i;
