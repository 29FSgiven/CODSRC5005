int (*fct)[42](int x);
