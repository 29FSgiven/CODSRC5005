char int i;
