enum rgb c = 42;
