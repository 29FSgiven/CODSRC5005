#!/bin/bash

../compiler/cc nini.evm
../compiler/cc test_arrays.evm
../compiler/cc test_extern.evm
../compiler/cc test_loops.evm
../compiler/cc test_math.evm
../compiler/cc test_pointer.evm
../compiler/cc test_strings.evm
