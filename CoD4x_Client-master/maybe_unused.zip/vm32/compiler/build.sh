#!/bin/bash

FLAGS="-g -Wall -O0"
./compile_lex_yacc.sh
gcc -c $FLAGS "codegen.c"
gcc -c $FLAGS "evmcomp.c"
gcc -c $FLAGS "insn.c"
gcc -c $FLAGS "output.c"
gcc -c $FLAGS "lex.yy.c"
gcc -c $FLAGS "y.tab.c"

echo Linking...
gcc $FLAGS -o cc *.o -static-libgcc -static -lstdc++ -Wl,-Map=vm.map
rm *.o
