/*
 *  EmbedVM - Embedded Virtual Machine for uC Applications
 *
 *  Copyright (C) 2011  Clifford Wolf <clifford@clifford.at>
 *  
 *  Permission to use, copy, modify, and/or distribute this software for any
 *  purpose with or without fee is hereby granted, provided that the above
 *  copyright notice and this permission notice appear in all copies.
 *  
 *  THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 *  WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 *  MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 *  ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 *  WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 *  ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 *  OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 */

#ifndef EMBEDVM_H
#define EMBEDVM_H

#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>


#ifdef  __cplusplus
extern "C" {
#endif

struct embedvm_s
{
	uint32_t ip, sp, sfp;
	uint32_t memsize, stacksize, codesize; //memsize is the amount of all memory, codesize and stacksize is a fractional part of memsize memory
	uint32_t endofstack; //End of stack is the lowest address the stack is allowed to grow
	void *user_ctx;

	int32_t (*mem_read)(uint32_t addr, bool is32bit, void *ctx);
	void (*mem_write)(uint32_t addr, int32_t value, bool is32bit, void *ctx);
	int32_t (*call_user)(uint8_t funcid, uint8_t argc, int32_t *argv, void *ctx);
};

extern void embedvm_exec(struct embedvm_s *vm);
extern void embedvm_interrupt(struct embedvm_s *vm, uint32_t addr);

int32_t embedvm_pop(struct embedvm_s *vm);
void embedvm_push(struct embedvm_s *vm, int32_t value);

int32_t embedvm_local_read(struct embedvm_s *vm, int8_t sfa);
void embedvm_local_write(struct embedvm_s *vm, int8_t sfa, int32_t value);

#ifdef __cplusplus
}
#endif

#endif
