
bool RSA_VerifyMemory(const char* expectedb64hash, const void* dercert, unsigned int dercertlen, const void* memory, int lenmem);
void TomCrypt_Init();